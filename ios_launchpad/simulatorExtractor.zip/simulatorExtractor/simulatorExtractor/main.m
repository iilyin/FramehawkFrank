//
//  main.m
//  simulatorExtractor
//
//  Created by Ivan Ilyin on 12/18/12.
//  Copyright (c) 2012 Ivan Ilyin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>

#pragma mark Window List & Window Image Methods
typedef struct
{
	// Where to add window information
	NSMutableArray * outputArray;
	// Tracks the index of the window when first inserted
	// so that we can always request that the windows be drawn in order.
	int order;
} WindowListApplierData;

NSString *kAppNameKey = @"applicationName";	// Application Name & PID
NSString *kWindowOriginKey = @"windowOrigin";	// Window Origin as a string
NSString *kWindowSizeKey = @"windowSize";		// Window Size as a string
NSString *kWindowIDKey = @"windowID";			// Window ID
NSString *kWindowLevelKey = @"windowLevel";	// Window Level
NSString *kWindowOrderKey = @"windowOrder";	// The overall front-to-back ordering of the windows as returned by the window server

void WindowListApplierFunction(const void *inputDictionary, void *context);
CFArrayRef newWindowListFromSelection(NSArray* selection);
CGRect boundingRect(CGRect rect1, CGRect rect2);

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        CGWindowListOption listOptions = 0 ;
        
        CFArrayRef windowList = CGWindowListCopyWindowInfo(listOptions, kCGNullWindowID);
        NSMutableArray * prunedWindowList = [NSMutableArray array];
        WindowListApplierData data = {prunedWindowList, 0};
        CFArrayApplyFunction(windowList, CFRangeMake(0, CFArrayGetCount(windowList)), &WindowListApplierFunction, &data);
        CFRelease(windowList);
        
        NSLog(@"windows list:");
        NSLog(@"%@", prunedWindowList);
        
        NSInteger order = -1;
        CGWindowID windowID = 0;
        CGRect windowRect;
        
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0 ; i < prunedWindowList.count; i++) {
            NSDictionary *windowData = [prunedWindowList objectAtIndex:i];
            NSString *appName = [windowData valueForKey:kAppNameKey];
            if ([appName rangeOfString:@"iOS Simulator"].location == 0)
            {
                NSNumber *orderV = [windowData objectForKey:kWindowOrderKey];
                //if (order == -1 || orderV.integerValue < order)
                {
                    NSValue *origin = [windowData objectForKey:kWindowOriginKey];
                    if (origin.pointValue.y == 0)
                        continue;
                    NSValue *size = [windowData objectForKey:kWindowSizeKey];
                    if (order == -1)
                        windowRect = CGRectMake(origin.pointValue.x, origin.pointValue.y, size.sizeValue.width, size.sizeValue.height);
                    else
                    {
                        windowRect = boundingRect(windowRect, CGRectMake(origin.pointValue.x, origin.pointValue.y, size.sizeValue.width, size.sizeValue.height));
                        order = 1;
                    }

                    order = orderV.integerValue;
                    NSNumber *windId = [windowData objectForKey:kWindowIDKey];
                    windowID = windId.integerValue;
                    [array addObject:windowData];
                }
            }
        }
        
        
        CFArrayRef windowIDs = newWindowListFromSelection(array);

        
        CGImageRef windowImage = CGWindowListCreateImageFromArray(windowRect, windowIDs, 	kCGWindowImageDefault | kCGWindowImageBoundsIgnoreFraming);
    
        NSBitmapImageRep *bitmapRep = [[NSBitmapImageRep alloc] initWithCGImage:windowImage];
		// Create an NSImage and add the bitmap rep to it...
		NSImage *image = [[NSImage alloc] init];
		[image addRepresentation:bitmapRep];
		[bitmapRep release];
        [[bitmapRep representationUsingType:NSPNGFileType properties:nil] writeToFile:@"test.png" atomically:YES];

    }
    return 0;
}



void WindowListApplierFunction(const void *inputDictionary, void *context)
{
	NSDictionary *entry = (NSDictionary*)inputDictionary;
	WindowListApplierData *data = (WindowListApplierData*)context;
	
	// The flags that we pass to CGWindowListCopyWindowInfo will automatically filter out most undesirable windows.
	// However, it is possible that we will get back a window that we cannot read from, so we'll filter those out manually.
	int sharingState = [[entry objectForKey:(id)kCGWindowSharingState] intValue];
	if(sharingState != kCGWindowSharingNone)
	{
		NSMutableDictionary *outputEntry = [NSMutableDictionary dictionary];
		
		// Grab the application name, but since it's optional we need to check before we can use it.
		NSString *applicationName = [entry objectForKey:(id)kCGWindowOwnerName];
		if(applicationName != NULL)
		{
			// PID is required so we assume it's present.
			NSString *nameAndPID = [NSString stringWithFormat:@"%@ (%@)", applicationName, [entry objectForKey:(id)kCGWindowOwnerPID]];
			[outputEntry setObject:nameAndPID forKey:kAppNameKey];
		}
		else
		{
			// The application name was not provided, so we use a fake application name to designate this.
			// PID is required so we assume it's present.
			NSString *nameAndPID = [NSString stringWithFormat:@"((unknown)) (%@)", [entry objectForKey:(id)kCGWindowOwnerPID]];
			[outputEntry setObject:nameAndPID forKey:kAppNameKey];
		}
		
		// Grab the Window Bounds, it's a dictionary in the array, but we want to display it as a string
		CGRect bounds;
		CGRectMakeWithDictionaryRepresentation((CFDictionaryRef)[entry objectForKey:(id)kCGWindowBounds], &bounds);
		NSValue *originValue = [NSValue valueWithPoint:NSMakePoint(bounds.origin.x, bounds.origin.y)];
		[outputEntry setObject:originValue forKey:kWindowOriginKey];
		NSValue *sizeValue = [NSValue valueWithSize:NSMakeSize(bounds.size.width, bounds.size.height)];
		[outputEntry setObject:sizeValue forKey:kWindowSizeKey];
		
		// Grab the Window ID & Window Level. Both are required, so just copy from one to the other
		[outputEntry setObject:[entry objectForKey:(id)kCGWindowNumber] forKey:kWindowIDKey];
		[outputEntry setObject:[entry objectForKey:(id)kCGWindowLayer] forKey:kWindowLevelKey];
		
		// Finally, we are passed the windows in order from front to back by the window server
		// Should the user sort the window list we want to retain that order so that screen shots
		// look correct no matter what selection they make, or what order the items are in. We do this
		// by maintaining a window order key that we'll apply later.
		[outputEntry setObject:[NSNumber numberWithInt:data->order] forKey:kWindowOrderKey];
		data->order++;
		
		[data->outputArray addObject:outputEntry];
	}
}

CFArrayRef newWindowListFromSelection(NSArray* selection)
{
	// Create a sort descriptor array. It consists of a single descriptor that sorts based on the kWindowOrderKey in ascending order
	NSArray * sortDescriptors = [NSArray arrayWithObject:[[[NSSortDescriptor alloc] initWithKey:kWindowOrderKey ascending:YES] autorelease]];
    
	// Next sort the selection based on that sort descriptor array
	NSArray * sortedSelection = [selection sortedArrayUsingDescriptors:sortDescriptors];
    
	// Now we Collect the CGWindowIDs from the sorted selection
	CGWindowID *windowIDs = calloc([sortedSelection count], sizeof(CGWindowID));
	int i = 0;
	for(NSMutableDictionary *entry in sortedSelection)
	{
		windowIDs[i++] = [[entry objectForKey:kWindowIDKey] unsignedIntValue];
	}
	// CGWindowListCreateImageFromArray expect a CFArray of *CGWindowID*, not CGWindowID wrapped in a CF/NSNumber
	// Hence we typecast our array above (to avoid the compiler warning) and use NULL CFArray callbacks
	// (because CGWindowID isn't a CF type) to avoid retain/release.
	CFArrayRef windowIDsArray = CFArrayCreate(kCFAllocatorDefault, (const void**)windowIDs, [sortedSelection count], NULL);
	free(windowIDs);
	
	// And send our new array on it's merry way
	return windowIDsArray;
}

CGRect boundingRect(CGRect rect1, CGRect rect2)
{
    CGFloat minx =  fmin(CGRectGetMinX(rect1), CGRectGetMinX(rect2));
    CGFloat maxx =  fmax(CGRectGetMaxX(rect1), CGRectGetMaxX(rect2));
    CGFloat miny =  fmin(CGRectGetMinY(rect1), CGRectGetMinY(rect2));
    CGFloat maxy =  fmax(CGRectGetMaxY(rect1), CGRectGetMaxY(rect2));
    return CGRectMake(minx, miny, maxx - minx, maxy - miny);
}


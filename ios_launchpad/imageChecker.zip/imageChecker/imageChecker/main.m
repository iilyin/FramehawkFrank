//
//  main.m
//  imageChecker
//
//  Created by Ivan Ilyin on 12/18/12.
//  Copyright (c) 2012 Ivan Ilyin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

bool testImage(NSString* imageName, NSUInteger x, NSUInteger y, NSString* testName);

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSString *fileName = [NSString stringWithCString:argv[1] encoding:NSASCIIStringEncoding];
        NSString *checkImageName = [NSString stringWithCString:argv[2] encoding:NSASCIIStringEncoding];
        NSString *yCoord = [NSString stringWithCString:argv[4] encoding:NSASCIIStringEncoding];
        NSUInteger x = atoi(argv[3]);
        NSUInteger y = atoi(argv[4]);
        
        if (testImage(fileName, x, y, checkImageName))
        {
            NSLog(@"PASSED");
            return 0;
        }
        else
        {
            NSLog(@"FAILED");
            return 1;
        }
    }
}

bool testImage(NSString* imageName, NSUInteger x, NSUInteger y, NSString* testName)
{
    NSBitmapImageRep *imageRep1 = [NSBitmapImageRep imageRepWithContentsOfFile:imageName];
    NSBitmapImageRep *imageRep2 = [NSBitmapImageRep imageRepWithContentsOfFile:testName];
    
    NSUInteger bmp1[4];
    NSUInteger bmp2[4];
    
    int cx,cy;
    for (cx = 0; cx < imageRep2.size.width; cx++)
    {
        for (cy = 0; cy < imageRep2.size.height; cy++)
        {
            [imageRep1 getPixel:bmp1 atX:x + cx y:y + cy];
            [imageRep2 getPixel:bmp2 atX:cx y:cy];
            if (memcmp(bmp1, bmp2, 12) != 0)
                break;
        }
        
        if (cy != imageRep2.size.height)
            break;
    }
    
    return cx == (NSUInteger)imageRep2.size.width && cy == (NSUInteger)imageRep2.size.height;
}